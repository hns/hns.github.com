// JS 1.8/Harmony destructuring assignment
var {ByteArray, ByteString} = require('binary');
var {HashMap, TreeMap} = java.util;

// long pre-JS 1.8 version
var binary = require('binary'),
    ByteArray = binary.ByteArray,
    ByteString = binary.ByteString;

// ES5 Object.defineProperty
Object.defineProperty(exports, 'foo', {
    value: 'bar'
});
