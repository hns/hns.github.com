var fs = require('fs');
var {GREEN, BLUE, writeln} = require('ringo/term');

// text streams have an iterator that reads the next line
var file = fs.open('file.js');  // text mode
for (var line in file)
   writeln(GREEN, line);

// binary streams read into ByteArrays/ByteStrings
file = fs.open('file.js', {binary: true});
writeln(BLUE, file.read())
